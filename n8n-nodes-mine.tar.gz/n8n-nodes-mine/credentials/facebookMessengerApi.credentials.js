"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.facebookMessengerApi = void 0;
class facebookMessengerApi {
    constructor() {
        this.name = 'facebookMessengerApi';
        this.displayName = 'Facebook Messenger Credentials API';
        this.icon = 'file:../nodes/FacebookMessenger/icon/facebook-messenger.svg';
        this.properties = [
            {
                displayName: 'Access Token',
                name: 'accessToken',
                type: 'string',
                default: '',
                typeOptions: {
                    password: true,
                }
            },
        ];
        this.authenticate = {
            type: 'generic',
            properties: {
                qs: {
                    access_token: '={{$credentials.accessToken}}',
                },
            },
        };
        this.test = {
            request: {
                baseURL: 'https://graph.facebook.com/v8.0',
                url: '/me',
            },
        };
    }
}
exports.facebookMessengerApi = facebookMessengerApi;
//# sourceMappingURL=facebookMessengerApi.credentials.js.map