"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacebookMessengerSendTextMessage = void 0;
class FacebookMessengerSendTextMessage {
    constructor() {
        this.description = {
            displayName: 'Messenger Send Text Message',
            name: 'facebookMessengerSendTextMessage',
            icon: 'file:icon/facebook-messenger.svg',
            group: ['output'],
            version: 1,
            description: 'Marks a message as read, shows typing, and sends a text message via Facebook Messenger.',
            defaults: {
                name: 'Messenger Send Text Message',
            },
            inputs: ['main'],
            outputs: [],
            credentials: [
                {
                    name: 'facebookMessengerApi',
                    required: true,
                },
            ],
            properties: [
                {
                    displayName: 'Recipient ID',
                    name: 'recipientId',
                    type: 'string',
                    required: true,
                    default: '',
                    description: 'The recipient\'s user ID',
                },
                {
                    displayName: 'Message Text',
                    name: 'messageText',
                    type: 'string',
                    required: true,
                    default: '',
                    description: 'The text of the message to send',
                },
                {
                    displayName: 'Mark Message as Read',
                    name: 'markRead',
                    type: 'boolean',
                    default: true,
                    description: 'Whether to mark the message as read before showing typing and sending',
                },
                {
                    displayName: 'Show Typing Indicator',
                    name: 'showTyping',
                    type: 'boolean',
                    default: true,
                    description: 'Whether to show the typing indicator before sending the message',
                },
                {
                    displayName: 'API Version',
                    name: 'apiVersion',
                    type: 'options',
                    options: [
                        {
                            name: 'v22.0',
                            value: 'v22.0',
                        },
                        {
                            name: 'v21.0',
                            value: 'v21.0',
                        },
                        {
                            name: 'v20.0',
                            value: 'v20.0',
                        },
                        {
                            name: 'v19.0',
                            value: 'v19.0',
                        },
                        {
                            name: 'v18.0',
                            value: 'v18.0',
                        },
                        {
                            name: 'v17.0',
                            value: 'v17.0',
                        },
                        {
                            name: 'v16.0',
                            value: 'v16.0',
                        },
                        {
                            name: 'v15.0',
                            value: 'v15.0',
                        },
                        {
                            name: 'v14.0',
                            value: 'v14.0',
                        },
                        {
                            name: 'v13.0',
                            value: 'v13.0',
                        },
                        {
                            name: 'v12.0',
                            value: 'v12.0',
                        },
                        {
                            name: 'v11.0',
                            value: 'v11.0',
                        },
                        {
                            name: 'v10.0',
                            value: 'v10.0',
                        },
                        {
                            name: 'v9.0',
                            value: 'v9.0',
                        },
                        {
                            name: 'v8.0',
                            value: 'v8.0',
                        },
                        {
                            name: 'v7.0',
                            value: 'v7.0',
                        },
                        {
                            name: 'v6.0',
                            value: 'v6.0',
                        },
                        {
                            name: 'v5.0',
                            value: 'v5.0',
                        },
                        {
                            name: 'v4.0',
                            value: 'v4.0',
                        },
                        {
                            name: 'v3.3',
                            value: 'v3.3',
                        },
                        {
                            name: 'v3.2',
                            value: 'v3.2',
                        },
                        {
                            name: 'v3.1',
                            value: 'v3.1',
                        },
                        {
                            name: 'v3.0',
                            value: 'v3.0',
                        },
                    ],
                    default: 'v22.0',
                    description: 'The Facebook Graph API version to use',
                    required: true,
                },
            ],
        };
    }
    async execute() {
        const items = this.getInputData();
        const returnData = [];
        for (let i = 0; i < items.length; i++) {
            try {
                const recipientId = this.getNodeParameter('recipientId', i);
                const messageText = this.getNodeParameter('messageText', i);
                const markRead = this.getNodeParameter('markRead', i);
                const showTyping = this.getNodeParameter('showTyping', i);
                const apiVersion = this.getNodeParameter('apiVersion', i);
                const credentials = await this.getCredentials('facebookMessengerApi');
                if (!credentials) {
                    throw new Error('Facebook Messenger API credentials are missing.');
                }
                const pageAccessToken = credentials.accessToken;
                const baseUrl = `https://graph.facebook.com/${apiVersion}/me/messages?access_token=${pageAccessToken}`;
                if (markRead) {
                    const readOptions = {
                        method: 'POST',
                        url: baseUrl,
                        body: {
                            recipient: {
                                id: recipientId,
                            },
                            sender_action: 'mark_seen',
                        },
                        json: true,
                    };
                    await this.helpers.httpRequest(readOptions);
                }
                if (showTyping) {
                    const typingOptions = {
                        method: 'POST',
                        url: baseUrl,
                        body: {
                            recipient: {
                                id: recipientId,
                            },
                            sender_action: 'typing_on',
                        },
                        json: true,
                    };
                    await this.helpers.httpRequest(typingOptions);
                }
                const messageOptions = {
                    method: 'POST',
                    url: baseUrl,
                    body: {
                        recipient: {
                            id: recipientId,
                        },
                        message: {
                            text: messageText,
                        },
                    },
                    json: true,
                };
                const messageResponse = await this.helpers.httpRequest(messageOptions);
                returnData.push({
                    json: messageResponse,
                    data: items[i].data,
                });
            }
            catch (error) {
                returnData.push({
                    json: {
                        message: error.message,
                        stack: error.stack,
                    },
                    data: items[i].data,
                });
            }
        }
        return [returnData];
    }
}
exports.FacebookMessengerSendTextMessage = FacebookMessengerSendTextMessage;
//# sourceMappingURL=FacebookMessengerSendTextMessage.node.js.map