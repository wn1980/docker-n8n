"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacebookMessengerWebhook = void 0;
class FacebookMessengerWebhook {
    constructor() {
        this.description = {
            displayName: 'Messenger Webhook',
            name: 'facebookMessengerWebhook',
            icon: 'file:icon/facebook-messenger-trigger.svg',
            group: ['trigger'],
            version: 1,
            description: 'Triggers when events occur in Facebook Messenger',
            defaults: {
                name: 'Messenger Webhook',
            },
            inputs: [],
            outputs: [
                { type: 'main', displayName: 'text' },
                { type: 'main', displayName: 'attachment' },
                { type: 'main', displayName: 'postback' },
            ],
            webhooks: [
                {
                    name: 'default',
                    httpMethod: 'POST',
                    responseMode: 'onReceived',
                    path: 'webhook',
                },
                {
                    name: 'setup',
                    httpMethod: 'GET',
                    responseMode: 'onReceived',
                    path: 'webhook',
                },
            ],
            properties: [
                {
                    displayName: 'Verify Token',
                    name: 'verifyToken',
                    type: 'string',
                    required: true,
                    default: '',
                    typeOptions: { password: true },
                    description: 'The verify token used for webhook verification',
                },
            ],
        };
    }
    async webhook() {
        const req = this.getRequestObject();
        const res = this.getResponseObject();
        const requestMethod = this.getRequestObject().method;
        if (requestMethod === 'GET') {
            if (req.query['hub.mode'] === 'subscribe' && req.query['hub.verify_token'] === this.getNodeParameter('verifyToken')) {
                console.log("Webhook is verified! (•‿•)");
                res.status(200).send(req.query['hub.challenge']).end();
            }
            else {
                console.error("Failed validation! ( ˇ෴ˇ ) \nMake sure the validation tokens match.");
                res.sendStatus(403);
            }
            return {
                noWebhookResponse: true,
            };
        }
        if (req.body && req.body.object === 'page') {
            const entries = req.body.entry;
            console.log("entries: ", JSON.stringify(entries));
            const textItems = [];
            const attachmentItems = [];
            const postbackItems = [];
            for (const entry of entries) {
                const messagingEvents = entry.messaging;
                if (messagingEvents) {
                    for (const event of messagingEvents) {
                        if (event.message) {
                            if (event.message.text) {
                                console.log("eventType: event.message.text");
                                textItems.push({
                                    json: {
                                        userId: event.sender.id,
                                        messageText: event.message.text,
                                    }
                                });
                            }
                            else if (event.message.attachments) {
                                console.log("eventType: event.message.attachments");
                                attachmentItems.push({
                                    json: {
                                        userId: event.sender.id,
                                        messageAttachments: event.message.attachments,
                                    }
                                });
                            }
                        }
                        else if (event.postback) {
                            console.log("eventType: event.postback");
                            postbackItems.push({
                                json: {
                                    userId: event.sender.id,
                                    postback: event.postback,
                                }
                            });
                        }
                    }
                }
            }
            const workflowData = [
                textItems,
                attachmentItems,
                postbackItems,
            ];
            return {
                workflowData: workflowData,
                webhookResponse: 'OK',
            };
        }
        return {
            webhookResponse: 'Invalid request',
        };
    }
}
exports.FacebookMessengerWebhook = FacebookMessengerWebhook;
//# sourceMappingURL=FacebookMessengerWebhook.node.js.map